# plugins/TESTING/Global Variable Tester/tester_plugin.py
from typing import Any, Dict, List
import time

from plugins.base_plugin import BasePlugin
from core.data_models import DataPayload, PluginSettingSpec

class GlobalVariableTester(BasePlugin):
    def __init__(self):
        super().__init__(
            name="Global Variable Tester",
            description="Plugin untuk menguji variabel global, notifikasi, dan queue."
        )

    def get_gui_config_spec(self) -> List[PluginSettingSpec]:
        """
        Plugin ini tidak memerlukan konfigurasi GUI.
        """
        return []

    def run(self, data_payload: DataPayload, app_settings: Dict[str, Any]) -> DataPayload:
        """
        Fungsi utama yang akan dijalankan oleh workflow executor.
        """
        self._log("Memulai pengujian fungsionalitas inti...", "INFO")

        # 1. Tes Variabel Global & State Manager
        # -----------------------------------------------------------------
        self.report_progress(1, 4, "Menguji Variabel Global...")
        self._log("Membaca Variabel Global 'NAMA_SAYA'...", "INFO")

        # Dapatkan semua variabel global dari settings_manager
        all_global_vars = self.settings_manager.get_all_global_variables()
        nama_saya_var = next((var for var in all_global_vars if var.key == 'NAMA_SAYA'), None)
        
        if nama_saya_var:
            self._log(f"Nilai 'NAMA_SAYA' saat ini adalah: '{nama_saya_var.value}'", "INFO")
            pesan_notif = f"Variabel Global 'NAMA_SAYA' ditemukan dengan nilai: {nama_saya_var.value}"
        else:
            self._log("Variabel Global 'NAMA_SAYA' tidak ditemukan. Buat di tab Setting > Variabel Global terlebih dahulu.", "WARNING")
            pesan_notif = "Variabel Global 'NAMA_SAYA' tidak ditemukan. Silakan buat dulu!"

        # Tes State Manager dengan cara menambah counter
        self.report_progress(2, 4, "Menguji State Manager...")
        run_count = self.app.state_manager.increment_state("TESTER_PLUGIN_RUN_COUNT")
        self._log(f"Plugin ini telah dijalankan sebanyak {run_count} kali.", "INFO")
        
        time.sleep(1) # Jeda agar bisa dibaca

        # 2. Tes Notifikasi Desktop
        # -----------------------------------------------------------------
        self.report_progress(3, 4, "Mengirim Notifikasi Desktop...")
        self._log("Mencoba mengirim notifikasi desktop...", "INFO")
        
        try:
            # Menggunakan notif_service yang sudah di-inject oleh MainApp
            self.app.notif_service.send(
                title="✅ Tes Notifikasi Berhasil",
                message=f"{pesan_notif}\nPlugin ini telah dijalankan {run_count} kali.",
                notif_type="success"
            )
            self._log("Perintah notifikasi berhasil dikirim.", "INFO")
        except Exception as e:
            self._log(f"Gagal mengirim notifikasi: {e}", "ERROR")

        time.sleep(1) # Jeda

        # 3. Tes Info Queue (dengan logging)
        # -----------------------------------------------------------------
        self.report_progress(4, 4, "Mengirim Log ke Antrian...")
        self._log("Ini adalah pesan log terakhir dari plugin test.", "DEBUG")
        self._log("Pengujian selesai!", "INFO")

        # Mengembalikan data payload tanpa perubahan
        return data_payload