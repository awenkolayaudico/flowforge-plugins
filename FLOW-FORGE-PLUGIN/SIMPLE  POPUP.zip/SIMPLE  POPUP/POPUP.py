# plugins/utilities/simple_popup_plugin.py
import tkinter as tk
from tkinter import messagebox
from plugins.base_plugin import BasePlugin
from core.data_models import DataPayload, PluginSettingSpec
from typing import Any, Dict, List

class SimplePopupDisplayPlugin(BasePlugin):
    def __init__(self):
        super().__init__(
            name="POP UP",
            description="POP UP SEDERHANA"
        )
        self.settings = {
            "popup_title": "PESAN",
            "popup_message": "PESAN KAMU DISINI",
            "popup_type": "info" # Pilihan: info, warning, error
        }

    def get_gui_config_spec(self) -> List[PluginSettingSpec]:
        """
        Mengembalikan spesifikasi untuk membangun GUI konfigurasi plugin.
        """
        return [
            PluginSettingSpec(
                field_name="popup_title",
                label="Judul Pop-up",
                type="str",
                default=self.settings["popup_title"],
                tooltip="Judul yang akan muncul di jendela pop-up.",
                placeholder="Judul Pesan Anda"
            ),
            PluginSettingSpec(
                field_name="popup_message",
                label="Pesan Pop-up",
                type="multiline_text", # Menggunakan multiline_text untuk pesan yang lebih panjang
                default=self.settings["popup_message"],
                tooltip="Isi pesan yang akan ditampilkan di jendela pop-up.",
                placeholder="Tulis pesan Anda di sini."
            ),
            PluginSettingSpec(
                field_name="popup_type",
                label="Tipe Pop-up",
                type="dropdown",
                options=["info", "warning", "error"], # Pilihan tipe pesan
                default=self.settings["popup_type"],
                tooltip="Menentukan ikon dan gaya pop-up (Info, Peringatan, atau Error)."
            )
        ]

    def run(self, data_payload: DataPayload, app_settings: Dict[str, Any]) -> DataPayload:
        """
        Logika inti plugin. Menampilkan jendela pop-up dengan pesan yang dikonfigurasi.
        """
        popup_title = self.settings.get("popup_title", "Notifikasi")
        popup_message = self.settings.get("popup_message", "Pesan kosong.")
        popup_type = self.settings.get("popup_type", "info").lower() # Pastikan lowercase untuk membandingkan

        self._log(f"Memulai eksekusi 'Simple Pop-up Display'.", level="INFO")
        self._log(f"Menampilkan pop-up: Judul='{popup_title}', Pesan='{popup_message}', Tipe='{popup_type}'", level="INFO")

        # Mengakses instance aplikasi utama untuk memastikan pop-up muncul di main thread Tkinter
        app_instance = app_settings.get("app_instance")
        if app_instance:
            # Menggunakan app.after(0, ...) untuk menjalankan messagebox di main thread
            # Karena messagebox (Tkinter) harus dijalankan dari main thread GUI
            if popup_type == "info":
                app_instance.after(0, lambda: messagebox.showinfo(popup_title, popup_message))
            elif popup_type == "warning":
                app_instance.after(0, lambda: messagebox.showwarning(popup_title, popup_message))
            elif popup_type == "error":
                app_instance.after(0, lambda: messagebox.showerror(popup_title, popup_message))
            else:
                app_instance.after(0, lambda: messagebox.showinfo(popup_title, popup_message)) # Default ke info

            self._log(f"Pop-up dengan tipe '{popup_type}' ditampilkan.", level="INFO")
            # --- PERBAIKAN: Tambahkan detail pop-up ke last_plugin_status ---
            data_payload.last_plugin_status[self.name] = {
                "success": True,
                "display_message": popup_message,
                "popup_title": popup_title, # Tambahkan judul
                "popup_message": popup_message, # Tambahkan seluruh pesan
                "popup_type": popup_type # Tambahkan tipe
            }
            # --- AKHIR PERBAIKAN ---
        else:
            self._log("Peringatan: Tidak dapat menampilkan pop-up karena instance aplikasi tidak tersedia.", level="WARNING")
            # Log error jika app_instance tidak tersedia, dan set status gagal di payload
            app_settings.get("error_logger").log_error(
                f"Plugin '{self.name}' gagal menampilkan pop-up: Instance aplikasi tidak tersedia.", exc_info=False
            )
            data_payload.last_plugin_status[self.name] = {
                "success": False,
                "error_message": "Instance aplikasi tidak tersedia untuk menampilkan pop-up.",
                "popup_title": popup_title,
                "popup_message": popup_message,
                "popup_type": popup_type
            }


        self._log(f"Eksekusi 'Simple Pop-up Display' selesai.", level="INFO")
        return data_payload