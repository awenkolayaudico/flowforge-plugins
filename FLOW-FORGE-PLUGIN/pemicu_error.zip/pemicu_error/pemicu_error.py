# plugins/utilitas/pemicu_error/pemicu_error.py
from typing import Any, Dict, List, Optional
from plugins.base_plugin import BasePlugin
from core.data_models import DataPayload, PluginSettingSpec

class PemicuError(BasePlugin):
    def __init__(self):
        # Inisialisasi plugin dengan nama dan deskripsi
        super().__init__(
            name="Pemicu Error",
            description="Plugin ini digunakan untuk simulasi keberhasilan atau kegagalan dalam workflow, ideal untuk menguji blok Try/Catch/Finally."
        )

    def get_gui_config_spec(self) -> List[PluginSettingSpec]:
        """
        Mendefinisikan pengaturan yang akan ditampilkan di GUI untuk plugin ini.
        """
        return [
            PluginSettingSpec(
                field_name="execution_mode",
                label="Mode Eksekusi",
                type="dropdown",
                options=["Selalu Berhasil", "Selalu Gagal"],
                default="Selalu Berhasil",
                tooltip="Pilih apakah plugin ini harus berhasil atau sengaja gagal untuk tujuan pengujian.",
                required=True
            ),
            PluginSettingSpec(
                field_name="log_message",
                label="Pesan Log",
                type="str",
                default="Plugin Pemicu Error dijalankan.",
                tooltip="Pesan yang akan ditampilkan di log saat plugin ini dieksekusi.",
                required=False
            )
        ]

    def get_status_keys(self) -> List[str]:
        """
        Melaporkan kunci status yang mungkin dihasilkan oleh plugin ini.
        """
        return ["success", "message", "mode"]

    def run(self, data_payload: DataPayload, app_settings: Dict[str, Any]) -> DataPayload:
        """
        Logika utama eksekusi plugin.
        """
        mode = self.settings.get("execution_mode", "Selalu Berhasil")
        message = self.settings.get("log_message", "Plugin Pemicu Error dijalankan.")

        self._log(f"Mode eksekusi dipilih: {mode}")
        self._log(f"Pesan log: {message}")

        if mode == "Selalu Gagal":
            self._log("Plugin dikonfigurasi untuk GAGAL. Memicu exception sekarang...", level="WARNING")
            # Baris ini akan menyebabkan error yang akan ditangkap oleh blok 'Catch'
            raise Exception("Kegagalan ini disengaja dari plugin Pemicu Error.")
        
        # Jika mode adalah "Selalu Berhasil"
        self._log("Plugin dikonfigurasi untuk BERHASIL.", level="INFO")
        
        # Perbarui status plugin terakhir untuk memberi tahu workflow bahwa plugin ini berhasil
        self.last_plugin_status = {
            "success": True,
            "message": f"Eksekusi berhasil. Pesan: {message}",
            "mode": mode
        }
        data_payload.last_plugin_status[self.name] = self.last_plugin_status
        
        return data_payload