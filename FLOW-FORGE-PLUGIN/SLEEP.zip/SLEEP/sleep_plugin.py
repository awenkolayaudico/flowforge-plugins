# plugins/UTILITIES/SLEEP_PLUGIN/sleep_plugin.py
import time
from typing import List, Dict, Any

from plugins.base_plugin import BasePlugin
from core.data_models import DataPayload, PluginSettingSpec

class SleepPlugin(BasePlugin):
    """
    Plugin sederhana untuk menjeda eksekusi alur kerja.
    """
    def __init__(self):
        # Inisialisasi plugin dengan nama dan deskripsi
        super().__init__(
            name="Sleep",
            description="Menjeda eksekusi alur kerja untuk durasi tertentu."
        )

    def get_gui_config_spec(self) -> List[PluginSettingSpec]:
        """
        Mendefinisikan pengaturan apa saja yang bisa dikonfigurasi oleh pengguna melalui GUI.
        """
        return [
            PluginSettingSpec(
                field_name="duration_seconds",
                label="Durasi Jeda (detik)",
                type="float",  # Menggunakan float agar bisa menerima angka desimal, misal: 0.5 detik
                default=1.0,
                placeholder="Contoh: 5",
                tooltip="Jumlah detik alur kerja akan dijeda. Bisa menggunakan desimal."
            )
        ]

    def run(self, data_payload: DataPayload, app_settings: Dict[str, Any]) -> DataPayload:
        """
        Metode utama yang akan dieksekusi oleh WorkflowExecutor.
        """
        # Ambil nilai durasi dari pengaturan yang sudah diset oleh pengguna
        # Jika tidak ada, gunakan nilai default 1.0 detik
        try:
            duration = float(self.settings.get('duration_seconds', 1.0))
        except (ValueError, TypeError):
            self._log("Nilai durasi tidak valid, menggunakan nilai default 1.0 detik.", level="WARNING")
            duration = 1.0

        if duration < 0:
            self._log(f"Durasi negatif ({duration}s) tidak diizinkan. Diubah menjadi 0.", level="WARNING")
            duration = 0

        self._log(f"Alur kerja dijeda selama {duration} detik...")
        
        # Fungsi inti dari plugin ini: time.sleep()
        # Ini akan menghentikan thread pekerja selama durasi yang ditentukan
        time.sleep(duration)
        
        self._log("Jeda selesai. Melanjutkan alur kerja.")

        # Plugin ini tidak mengubah data, jadi kita kembalikan payload apa adanya
        return data_payload

    def validate_settings(self) -> bool:
        """
        Memvalidasi pengaturan sebelum eksekusi.
        """
        duration_str = self.settings.get('duration_seconds')
        if duration_str is None:
            self._log("Pengaturan 'duration_seconds' tidak ditemukan. Validasi gagal.", level="ERROR")
            return False
        
        try:
            duration = float(duration_str)
            if duration < 0:
                self._log(f"Durasi tidak boleh negatif. Nilai saat ini: {duration}", level="ERROR")
                return False
        except (ValueError, TypeError):
            self._log(f"Nilai durasi '{duration_str}' bukan angka yang valid.", level="ERROR")
            return False
            
        return True