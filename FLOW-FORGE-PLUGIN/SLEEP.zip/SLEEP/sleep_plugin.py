# plugins/UTILITIES/SLEEP_PLUGIN/sleep_plugin.py
import time
import random  # <-- PENAMBAHAN BARU: Import modul random
from typing import List, Dict, Any

from plugins.base_plugin import BasePlugin
from core.data_models import DataPayload, PluginSettingSpec

class SleepPlugin(BasePlugin):
    """
    Plugin untuk menjeda eksekusi alur kerja dengan durasi tetap atau acak.
    """
    def __init__(self):
        super().__init__(
            name="Sleep",
            description="Menjeda eksekusi alur kerja untuk durasi tertentu."
        )

    def get_gui_config_spec(self) -> List[PluginSettingSpec]:
        """
        Memperbarui spesifikasi GUI untuk menerima format baru (angka atau rentang).
        """
        return [
            PluginSettingSpec(
                field_name="duration_spec",  # Nama field diubah agar lebih jelas
                label="Durasi Jeda (detik atau rentang)",
                type="str",  # Tipe diubah menjadi string untuk menerima format "1-10"
                default="1",
                placeholder="Contoh: 5 atau 1-10",
                tooltip="Masukkan angka tunggal (misal: 5) untuk jeda tetap, atau rentang (misal: 1-10) untuk jeda acak."
            )
        ]

    def run(self, data_payload: DataPayload, app_settings: Dict[str, Any]) -> DataPayload:
        """
        Metode utama yang akan dieksekusi oleh WorkflowExecutor.
        Sekarang dengan logika untuk menangani durasi acak.
        """
        duration_spec = self.settings.get('duration_spec', "1").strip()
        duration = 1.0  # Nilai default jika terjadi kesalahan

        try:
            # --- LOGIKA BARU UNTUK MEMPROSES INPUT ---
            if '-' in duration_spec:
                # Jika input adalah rentang (contoh: "1-10")
                parts = duration_spec.split('-')
                if len(parts) == 2:
                    min_duration = float(parts[0].strip())
                    max_duration = float(parts[1].strip())
                    
                    # Pastikan min tidak lebih besar dari max
                    if min_duration > max_duration:
                        min_duration, max_duration = max_duration, min_duration # Tukar posisi
                    
                    # Hasilkan angka acak dalam rentang
                    duration = random.uniform(min_duration, max_duration)
                    self._log(f"Rentang '{duration_spec}' dipilih. Durasi acak yang dihasilkan: {duration:.2f} detik.")
                else:
                    raise ValueError("Format rentang tidak valid. Gunakan format 'min-max'.")
            else:
                # Jika input adalah angka tunggal
                duration = float(duration_spec)
            # --- AKHIR LOGIKA BARU ---

            if duration < 0:
                self._log(f"Durasi negatif ({duration}s) tidak diizinkan. Diubah menjadi 0.", level="WARNING")
                duration = 0

        except (ValueError, TypeError) as e:
            self._log(f"Nilai durasi '{duration_spec}' tidak valid ({e}), menggunakan nilai default 1.0 detik.", level="WARNING")
            duration = 1.0

        self._log(f"Alur kerja dijeda selama {duration:.2f} detik...")
        time.sleep(duration)
        self._log("Jeda selesai. Melanjutkan alur kerja.")

        return data_payload

    def validate_settings(self) -> bool:
        """
        Memvalidasi format input baru.
        """
        duration_spec = self.settings.get('duration_spec')
        if not duration_spec or not duration_spec.strip():
            self._log("Pengaturan durasi tidak boleh kosong.", level="ERROR")
            return False
        
        duration_spec = duration_spec.strip()
        
        try:
            if '-' in duration_spec:
                parts = duration_spec.split('-')
                if len(parts) != 2:
                    self._log(f"Format rentang tidak valid: '{duration_spec}'. Harap gunakan format 'angka-angka'.", level="ERROR")
                    return False
                # Coba konversi kedua bagian ke float untuk memastikan keduanya adalah angka
                float(parts[0].strip())
                float(parts[1].strip())
            else:
                # Coba konversi ke float untuk memastikan ini adalah angka
                duration = float(duration_spec)
                if duration < 0:
                    self._log(f"Durasi tidak boleh negatif. Nilai saat ini: {duration}", level="ERROR")
                    return False
        except (ValueError, TypeError):
            self._log(f"Nilai durasi '{duration_spec}' bukan angka atau rentang angka yang valid.", level="ERROR")
            return False
            
        return True