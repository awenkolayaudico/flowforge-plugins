# plugins/TESTING/Queue Tester/queue_tester_plugin.py
from typing import Any, Dict, List
import time
import queue
from tkinter import messagebox  # <-- PERBAIKAN: Import messagebox yang lupa

from plugins.base_plugin import BasePlugin
from core.data_models import DataPayload, PluginSettingSpec

class QueueTester(BasePlugin):
    """
    Plugin ini secara khusus dirancang untuk menguji dan memvisualisasikan
    fungsionalitas antrian (queue) yang ditampilkan di status bar MainApp.
    Versi ini aman dan tidak mengganggu job worker utama.
    """
    def __init__(self):
        super().__init__(
            name="Queue Tester",
            description="Menambahkan beberapa pekerjaan palsu ke antrian untuk melihat pembaruan UI."
        )

    def get_gui_config_spec(self) -> List[PluginSettingSpec]:
        """
        Plugin ini tidak memerlukan konfigurasi GUI.
        """
        return []

    def run(self, data_payload: DataPayload, app_settings: Dict[str, Any]) -> DataPayload:
        """
        Fungsi utama yang akan mensimulasikan penambahan dan pengurangan pekerjaan di antrian.
        """
        self._log("Memulai pengujian Antrian (Queue) versi aman...", "INFO")
        
        # Dapatkan akses langsung ke job_queue dari instance MainApp
        # Ini adalah antrian asli yang akan kita manipulasi HANYA untuk tampilan
        real_job_queue = self.app.job_queue
        if not real_job_queue:
            self._log("ERROR: Tidak dapat menemukan job_queue di instance MainApp.", "ERROR")
            return data_payload

        # --- PERBAIKAN: Gunakan antrian lokal untuk pekerjaan palsu ---
        # Ini untuk mencegah pekerjaan palsu diproses oleh job_worker utama.
        local_fake_queue = queue.Queue()

        # 1. Simulasi Menambahkan Pekerjaan ke Antrian
        # ----------------------------------------------------
        jumlah_tes = 5
        self._log(f"Akan menambahkan {jumlah_tes} pekerjaan palsu ke antrian...", "INFO")
        self.report_progress(0, jumlah_tes, f"Menambahkan {jumlah_tes} pekerjaan ke antrian.")
        
        for i in range(jumlah_tes):
            # Masukkan pekerjaan palsu ke antrian LOKAL dan antrian ASLI
            fake_job_name = f"pekerjaan_palsu_{i+1}"
            local_fake_queue.put(fake_job_name)
            real_job_queue.put(fake_job_name) # Ini HANYA untuk mengubah angka di UI
            
            self._log(f"Menambahkan '{fake_job_name}'. Ukuran antrian UI: {real_job_queue.qsize()}", "DEBUG")
            self.report_progress(i + 1, jumlah_tes, f"Pekerjaan {i+1} ditambahkan.")
            time.sleep(1) # Jeda 1 detik agar perubahan terlihat

        self._log("Semua pekerjaan palsu berhasil ditambahkan ke antrian UI.", "INFO")
        messagebox.showinfo("Antrian Penuh", f"{jumlah_tes} pekerjaan palsu telah ditambahkan ke antrian.\n\nSekarang perhatikan Info Queue akan berkurang satu per satu.")

        # 2. Simulasi Menghabiskan Pekerjaan dari Antrian
        # ----------------------------------------------------
        self._log("Sekarang akan menghabiskan pekerjaan dari antrian...", "INFO")
        self.report_progress(0, jumlah_tes, "Menghabiskan antrian...")

        while not local_fake_queue.empty():
            # Ambil dari antrian LOKAL dan antrian ASLI
            local_fake_queue.get()
            try:
                # Ambil dari antrian asli untuk mengurangi angkanya di UI
                job_palsu_ui = real_job_queue.get_nowait()
                self._log(f"Menghabiskan '{job_palsu_ui}' dari antrian UI. Ukuran: {real_job_queue.qsize()}", "DEBUG")
                self.report_progress(local_fake_queue.qsize(), jumlah_tes, f"Pekerjaan selesai, sisa {local_fake_queue.qsize()}.")
                time.sleep(1) # Jeda 1 detik
            except queue.Empty:
                self._log("Antrian UI sudah kosong, proses selesai.", "WARNING")
                break
        
        self._log("Pengujian antrian selesai!", "INFO")
        
        return data_payload